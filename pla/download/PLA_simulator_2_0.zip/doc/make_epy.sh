#!/bin/bash
# da eseguire nella directory PLA.../

declare -a ops
ops=(--html --pdf)

for i in ${ops[*]}
do
  echo $i
  epydoc $i -o doc/refdoc --url ../.. --name "Programmable Logic Array Simulator - Alice Plebe, Matteo Cavallaro" code/pla.py code/circuits.py code/component.py
done
