#!/bin/bash
# da eseguire nella directory pla/.

filename="PLA_simulator_2_0.zip"

#rm -r "./download/$filename"
rm -f "./download/$filename"
zip -r "./download/$filename" .
